const bcrypt = require("bcrypt");
const usersSchema = require("../schemas/usersSchema");
const jwt = require("jsonwebtoken");
const joiFormatter = require("../helpers/joiFormatter");
const { Op } = require("sequelize");
const {
  generateRefreshToken,
  generateAccessToken,
} = require("../helpers/jwtKeyGenerator");
const {
  refreshCookieOptions,
  accessCookieOptions,
} = require("../constants/cookieOptions");

const login = async (req, res) => {};

const register = async (req, res) => {};

const logout = async (req, res) => {};

const refresh = async (req, res) => {};

module.exports = {
  login,
  refresh,
  register,
  logout,
};
