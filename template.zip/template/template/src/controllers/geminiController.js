const { Op } = require("sequelize");
const { News, Users } = require("../models");
const { default: axios } = require("axios");
const promptFormatter = require("../helpers/promptFormatter");
const formatDisplay = require("../helpers/formatDisplay");

const geminiSummarize = async (req, res) => {};

module.exports = {
  geminiSummarize,
};
