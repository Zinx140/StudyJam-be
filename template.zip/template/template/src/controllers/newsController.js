const { default: axios, head } = require("axios");
const { News, Users } = require("../models");
const jwt = require("jsonwebtoken");

const fetchAllNews = async (req, res) => {};

const fetchNewsByID = async (req, res) => {};

const createNews = async (req, res) => {};

const updateNews = async (req, res) => {};

const deleteNews = async (req, res) => {};

module.exports = {
  fetchAllNews,
  fetchNewsByID,
  createNews,
  updateNews,
  deleteNews,
};
