const jwt = require("jsonwebtoken");
const { Users, Roles } = require("../models");

const authorization = (module_name, permission) => {
  return async (req, res, next) => {
    next();
  };
};

module.exports = authorization;
