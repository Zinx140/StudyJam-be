"use strict";
const { Model } = require("sequelize");
module.exports = (sequelize, DataTypes) => {
  class News extends Model {
    static associate(models) {
      // News menyimpan author_id yang mengarah ke user_id Users,
      // maka ia "belongsTo" (milik) Users
      News.belongsTo(models.Users, {
        foreignKey: "author_id", // Kolom kunci di tabel News
        targetKey: "user_id", // // Kolom kunci di tabel Users
      });
    }
  }
  News.init(
    {
      news_id: {
        type: DataTypes.INTEGER,
        primaryKey: true,
        autoIncrement: true,
      },
      headline: {
        type: DataTypes.STRING(255),
        allowNull: false,
      },
      content: {
        type: DataTypes.TEXT,
        allowNull: false,
      },
    },
    {
      sequelize,
      modelName: "News",
      tableName: "news", // Nama Tabel dalam database
      paranoid: true, // mewakili kolom deletedAt
      timestamps: true, // mewakili updatedAt dan createdAt
      name: {
        // alias dalam memanggil model
        singular: "News",
        plural: "News",
      },
    },
  );
  return News;
};
