const Joi = require("joi");

const usersSchema = Joi.object({});

module.exports = usersSchema;
